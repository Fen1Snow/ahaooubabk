package config

const ServerHost = "0.0.0.0"
const ServerPort = "8080"
const ServerLog = "./../logs/livego.log"
