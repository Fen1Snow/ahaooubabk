# livego
go 实现直播服务
### 服务器部署
    chmod 755 server.sh<br/>
    ./server.sh &（依赖go环境，有些情况需要用vim 打开 set ff=unix 然后:wq） <br/>
    或者直接执行 ./LiveGoServer (不依赖go环境)
### 本地部署
    直接执行 LiveGoServer.exe
### use
    采用vue+webpack实现ui
    所有在config里
    日志在logs里
    http://localhost:8080/  (视频直播)<br/>
    http://localhost:8080/camera (录视频)(由于chrome的安全限制，建议在firefox下打开录视频页面)
### 使用效果
![](https://github.com/qieangel2013/livego/blob/master/public/images/live.png)
### livegoim
    livegoim是基于layui和layim开发的
    由于未开源，需要授权可以获取源代码
    有需要请私信联系我(904208360)
    付费交流群：229792939
http://www.weivq.com:88/ (演示地址)<br/>
http://www.weivq.com:88/public/uploads/LiveIm.apk (安卓演示)<br/>
http://www.weivq.com:88/public/uploads/LiveImInstall.exe (pc端演示)
![](https://github.com/qieangel2013/yaf/blob/master/public/images/windowspc.png)
### pc浏览器使用效果
![](https://github.com/qieangel2013/livego/blob/master/public/images/jt.png)
### mobile使用效果
![](https://github.com/qieangel2013/livego/blob/master/public/images/jtmobilet.png)
### 交流使用
    交流群：337937322
### 如果你对我的辛勤劳动给予肯定，请给我捐赠，你的捐赠是我最大的动力
![](https://github.com/qieangel2013/zys/blob/master/public/images/pw.jpg)
![](https://github.com/qieangel2013/livego/blob/master/public/images/pay.png)
[项目捐赠列表](https://github.com/qieangel2013/zys/wiki/%E9%A1%B9%E7%9B%AE%E6%8D%90%E8%B5%A0)
